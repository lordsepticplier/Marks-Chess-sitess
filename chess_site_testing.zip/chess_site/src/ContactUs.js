import './ContactUs.css';

function ContactUs() {
  return (
     <div class="contact_con text-center">
            <h1 class="card-text">Contact Us</h1>
            <h2 class="card-text">Harry - Admin</h2>
            <p class="card-text">harry.thornburrow@gmail.com</p>
            <p class="card-text">64-21-082-06451</p>
    </div>
  );
}

export default ContactUs;
