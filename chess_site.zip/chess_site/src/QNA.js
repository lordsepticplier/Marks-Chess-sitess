import './QNA.css';
import React, { useState } from "react";
import RightArrow from './images/right_arrow.png'
import LeftArrow from './images/left_arrow.png'


function QNA({ item}) {
  
  const [count, setCount] = useState(0);
  if(count>1){
    return (
      <div className='box'>
        <h3 className='Answer'>{item.Question}<ul className='Answers'>{item.Answer}</ul></h3>
        <button onClick={() => setCount(count - 1) }className='close'><img src={RightArrow} width="50px" height="auto" alt="logo" /></button>
      </div>   
    );
  }
  else{
    return (
      <div className='box'>
        <h3 className='Question'>{item.Question}</h3>
        <button onClick={() => setCount(count + 1)}className='expand'><img src={LeftArrow} width="50px" height="auto" alt="logo" /></button>
      </div>
      
    );
  }
}

export default QNA;